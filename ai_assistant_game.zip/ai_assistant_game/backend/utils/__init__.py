"""
Utility modules for the game assistant.
""" 