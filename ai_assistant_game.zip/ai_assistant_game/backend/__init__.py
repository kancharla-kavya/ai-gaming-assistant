"""
Backend package for the game assistant.
""" 